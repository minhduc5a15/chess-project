export interface ChatMessage {
  id?: string;
  username: string;
  content: string;
  createdAt: string;
}
