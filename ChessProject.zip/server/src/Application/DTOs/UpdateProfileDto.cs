namespace ChessProject.Application.DTOs;

public class UpdateProfileDto
{
    public string? Bio { get; set; }
}